#include "inverted.h"

int create_file_list(file_node **f_head, char *filename)
{
    file_node *new=malloc(sizeof(file_node));

    if(new==NULL)
    return FAILURE;

    strcpy(new->file,filename);         //copying filename into list
    new->link=NULL;

    if(*f_head==NULL)         //if no nodes are present
    {
        *f_head=new;       
    }
    else
    {
        file_node *temp = *f_head;
        while(temp->link != NULL)
        {
            temp=temp->link;
        }
        temp->link=new;
    }
    return SUCCESS;
}