#include "inverted.h"

int validation_store_file(char *store)
{
    if(strstr(store,".txt") == NULL)              //check if it is a .txt file
    {
        printf("%s is not a .txt file\n",store);
        return FAILURE;
    }
    return SUCCESS;
}

int save_db(hash_t arr[])
{
    char store[100];
    printf("Enter the file to store the data:");         //getting file name from user to store the backup data
    scanf("%s",store);
    if(validation_store_file(store)==FAILURE)     //validating that file before storing data
    {
        return FAILURE;
    }
    FILE *fptr=fopen(store,"w");    //opening file to write in it
    if(fptr == NULL)
    {
        printf("Unable to open file\n");
        return FAILURE;
    }
    for(int i=0; i < HASH_SIZE ; i++)
    {
        if(arr[i].link == NULL)
        {
           continue;
        }
        main_node *m_temp=arr[i].link;
        while(m_temp != NULL)
        {
            fprintf(fptr,"#%d;%s;%d;",i,m_temp->word,m_temp->f_count);

            sub_node *s_temp=m_temp->sub_link;      //taking pointer to traverse through sub node
            while(s_temp != NULL)
            {
                fprintf(fptr,"%s;%d;", s_temp->file, s_temp->word_count);
                s_temp=s_temp->sub_link;   //moving to next sub node
            }
            fprintf(fptr,"\n");
            m_temp = m_temp->main_link; 
        }
    }
    fclose(fptr);
    printf("\nDATA BASE SAVED SUCCESSFULLY\n");

    return SUCCESS;
}