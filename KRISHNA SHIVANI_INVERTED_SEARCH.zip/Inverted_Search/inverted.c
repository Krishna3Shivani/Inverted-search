/*
---------------------------------------------------------------------
                    INVERTED SEARCH SYSTEM
---------------------------------------------------------------------

    Name        : Inverted Search using Hashing
    Author      : KRISHNA SHIVANI S
    Date        : 27 / 04 / 2026

---------------------------------------------------------------------
Project Description :

This project implements an Inverted Search System using Hash Tables and Linked Lists in C. The system reads multiple
text files and creates an indexed database of words along with the files in which they appear.

Each word is stored in a hash table based on its index, and the corresponding file details are stored using linked lists. 
This structure allows fast searching, efficient storage, and easy retrieval of word information.

The program supports creating a database from files,searching words, displaying stored data, saving the database to a 
backup file, and updating the database from a saved backup file.

---------------------------------------------------------------------
Operations Supported :

    • Create Database
    • Search Word
    • Display Database
    • Save Database to File
    • Update Database from Backup

---------------------------------------------------------------------
Features :

    • Supports multiple input text files
    • Fast searching using Hash Table indexing
    • Efficient storage using Linked Lists
    • Handles hash collisions using chaining
    • Saves database into backup file
    • Restores database using update feature
    • Menu-driven user interface
    • Prevents duplicate file entries

---------------------------------------------------------------------
Concepts Used :

    • Hash Table
    • Singly Linked List
    • Nested Linked Lists
    • Dynamic Memory Allocation
    • File Handling
    • String Processing
    • Modular Programming

---------------------------------------------------------------------
Input Format :

The program accepts input through command-line arguments.

Compile Command :

        gcc *.c

Run Command :

        ./a.out <file1.txt> <file2.txt> <file3.txt> ...

Example :

        ./a.out f1.txt f2.txt f3.txt

---------------------------------------------------------------------
Menu Options :

        1. Create Database
        2. Search Database
        3. Display Database
        4. Save Database
        5. Update Database
        6. Exit

---------------------------------------------------------------------
Notes :

    • Input files must be in ".txt" format
    • Words are indexed using hashing technique
    • Backup file stores database structure
    • Update option restores database from backup
    • Searching is case-sensitive (if implemented)
    • Multiple files can contain the same word

---------------------------------------------------------------------
*/
#include "inverted.h"

int main(int argc, char *argv[])
{
    hash_t arr[HASH_SIZE];
    file_node *f_head = NULL;  //file list head
    //initialize hash table
    for(int i=0 ; i < HASH_SIZE ; i++)
    {
        arr[i].index = i;
        arr[i].link = NULL;
    }
    if(validation(argc,argv)==FAILURE)   //validating the files
    {
        return FAILURE;
    }
    //create file list
    for(int i=1 ; i<argc ; i++)
    {
        create_file_list(&f_head,argv[i]);
    }
    int choice;
    while(1)
    {
        printf("\n");
        printf("=========== MENU ===========\n");
        printf(" 1.Create database\n");
        printf(" 2.Search database\n");
        printf(" 3.Display database\n");
        printf(" 4.Save database\n");
        printf(" 5.Update database\n");
        printf(" 6.Exit\n");
        printf("============================\n");
        printf("Enter choice:");
        scanf("%d",&choice);

        switch(choice)
        {
            case 1:
            if(create_db(arr,f_head)==SUCCESS)
            {
                printf("\nDATABASE CREATED SUCCESSFULLY\n");
            }
            break;

            case 2:
            if(search_db(arr,f_head)==FAILURE)
            {
                printf("\nDATA NOT FOUND\n");
            }
            break;

            case 3:
            if(display_db(arr,f_head)==FAILURE)
            {
                printf("\nDATA BASE IS EMPTY\n");
            }
            break;

            case 4:
            if(save_db(arr)==FAILURE)
            {
                printf("\nDATA BASE IS NOT SAVED\n ");
            }
            break;

            case 5:
            if(update_db(arr)==SUCCESS)
            {
                printf("\nDATA BASE UPDATED SUCCESSFULLY\n");
            }
            else
            {
                printf("\nDATA BASE UPDATION FAILED\n");
            }
            break;

            case 6:
            printf("\nEXITING...\n");
            return 0;

            default:
            printf("Invalid choice. Please try again.\n");
        }
    }
}