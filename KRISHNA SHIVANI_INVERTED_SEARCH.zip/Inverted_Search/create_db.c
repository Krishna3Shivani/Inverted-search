#include "inverted.h"

int create_db(hash_t arr[],file_node *f_head)
{
    char word[50];
    int index;
    file_node *temp = f_head;     //storing f_head in a pointer to traverse file list

    while(temp != NULL)           //looping through the files
    {
        FILE *fptr=fopen(temp->file ,"r");  //open file in read mode
        if(fptr == NULL)
        return FAILURE;
        
        while(fscanf(fptr,"%s",word) != EOF)  //read a word from file
        {
            //find index
            if(word[0] >= 'a' && word[0] <= 'z')
            {
                index = word[0] - 'a';          //getting index value by asci value of 1st letter
            }
            else if(word[0] >= 'A' && word[0] <= 'Z')
            {
                index = word[0] - 'A'; 
            }
            else
            {
                index = 26;
            }
            if(arr[index].link==NULL)     //if no main node exists
            {
                //create a main node
                main_node *new_main = malloc(sizeof(main_node));
                if(new_main == NULL)
                return FAILURE;

                strcpy(new_main->word , word);   //copying word into main node
                new_main->f_count=1;             //updating f_count
                new_main->main_link=NULL;        //updating main link

                //create a sub node
                sub_node *new_sub = malloc(sizeof(sub_node));
                if(new_sub == NULL)
                return FAILURE;

                strcpy(new_sub->file,temp->file);      //copying file name in sub node
                new_sub->word_count=1;                 //updating word count
                new_sub->sub_link=NULL;                //updating sub link

                new_main->sub_link = new_sub;         //link subnode to main node

                arr[index].link = new_main;          //link HT with main node
            }
            else                                      //checking for the word in main node
            {
                main_node *m_temp = arr[index].link;
                main_node *prev = NULL;

                while(m_temp != NULL)         //traversing through the main node list
                {
                    if(strcmp(m_temp->word,word)==0)   //checking if word already exists
                    {
                        sub_node *s_temp = m_temp->sub_link;  
                        while(s_temp != NULL)      //traversing through the sub node list
                        {
                            if(strcmp(s_temp->file,temp->file)==0)   //checking if files are same
                            {
                                s_temp->word_count++;    //increase word count if word is found again in same file
                                break;
                            }
                            s_temp=s_temp->sub_link;
                        }
                        // File not found → create new sub node
                        if(s_temp==NULL)
                        {
                            sub_node *new_sub = malloc(sizeof(sub_node));
                            if(new_sub == NULL)
                            return FAILURE;

                            strcpy(new_sub->file,temp->file);      //copying file name in sub node
                            new_sub->word_count=1;                 //updating word count
                            new_sub->sub_link=m_temp->sub_link;                //updating sub link

                            m_temp->sub_link=new_sub;     //linking new sub node with main node
                            m_temp->f_count++;            //increment file count
                        }
                        break;
                    }
                    prev=m_temp;
                    m_temp=m_temp->main_link;      //updating m_temp to traverse
                }
                if(m_temp == NULL)                 //when word is not found,create main node
                {
                    main_node *new_main = malloc(sizeof(main_node));
                    if(new_main == NULL)
                    return FAILURE;
                    
                    strcpy(new_main->word , word);   //copying word into main node
                    new_main->f_count=1;             //updating f_count
                    new_main->main_link=NULL;        //updating main link

                    sub_node *new_sub = malloc(sizeof(sub_node));
                    if(new_sub == NULL)
                    return FAILURE;

                    strcpy(new_sub->file,temp->file);      //copying file name in sub node
                    new_sub->word_count=1;                 //updating word count
                    new_sub->sub_link=NULL;    //updating sub link

                    new_main->sub_link = new_sub;
                    if(prev==NULL)
                    arr[index].link = new_main;
                    else
                    prev->main_link = new_main;
                }
            }
        } 
        fclose(fptr);
        temp=temp->link;       //move to next file
    }
    return SUCCESS;
}