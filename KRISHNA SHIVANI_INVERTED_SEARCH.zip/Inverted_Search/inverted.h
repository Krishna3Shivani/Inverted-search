#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define FAILURE -1
#define HASH_SIZE 27

typedef struct hash_node       //structure for hash table
{
    int index;
    struct main_node *link;    //points to main node link
}hash_t;

typedef struct main_node      //structure for main node to store word info
{
    char word[50];
    int f_count;
    struct sub_node *sub_link;   //points to file list
    struct main_node *main_link;  //next word
    
}main_node;

typedef struct sub_node         //structure to store file details
{
    char file[50];
    int word_count;
    struct sub_node *sub_link;  //next file
}sub_node;

typedef struct file_node        //file list node
{
    char file[50];
    struct file_node *link;
}file_node;

int validation(int argc, char *argv[]);
int create_file_list(file_node **f_head, char *filename);
int create_db(hash_t arr[], file_node *f_head);
int search_db(hash_t arr[], file_node *f_head);
int display_db(hash_t arr[],file_node *f_head);
int save_db(hash_t arr[]);
int update_db(hash_t arr[]);