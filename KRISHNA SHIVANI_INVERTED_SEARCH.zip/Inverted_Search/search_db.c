#include "inverted.h"

int search_db(hash_t arr[],file_node *f_head)
{
    char word[30];
    printf("Enter the word to search : ");   //getting word from user to search
    scanf("%s",word);

    int index;
    if(word[0] >= 'a' && word[0] <= 'z')
    {
        index = word[0] - 'a';          //getting index value by asci value of 1st letter
    }
    else if(word[0] >= 'A' && word[0] <= 'Z')
    {
        index = word[0] - 'A'; 
    }
    else
    {
        index = 26;
    }
    if(arr[index].link==NULL)        //no main node is linked means no data is present
    {
        return FAILURE;
    }
    
    printf("\n");
    printf("==================== INVERTED SEARCH DATABASE ====================\n");

    printf("+-------+------------+-------------+---------------+-------------+\n");
    printf("| Index | Word       | File Count | File Name     | Word Count |\n");
    printf("+-------+------------+-------------+---------------+-------------+\n");

    main_node *m_temp=arr[index].link;   //taking a pointer to traverse through main node
    while(m_temp != NULL)
    {
        if(strcmp(m_temp->word,word)==0)    //comparing main node's word with user given word
        {
            sub_node *s_temp=m_temp->sub_link;      //taking pointer to traverse through sub node

            if(s_temp != NULL)         //printing only first row
            {
                printf("| %-5d | %-10.10s | %-11d | %-13.13s | %-11d |\n", index, m_temp->word, m_temp->f_count, s_temp->file, s_temp->word_count);
                s_temp=s_temp->sub_link;   //moving to next sub node
            }

            while(s_temp != NULL)
            {
                printf("|       |            |             | %-13.13s | %-11d |\n",s_temp->file,s_temp->word_count);
                s_temp=s_temp->sub_link;   //moving to next sub node
            }
            printf("+-------+------------+-------------+---------------+-------------+\n");
            printf("==================================================================\n");
            return SUCCESS;
        }
        m_temp=m_temp->main_link;    //moving to next main node
    }

    return FAILURE;      //data is not found in files

}