#include "inverted.h"

int display_db(hash_t arr[],file_node *f_head)
{
    int flag=0;
    printf("\n");
    printf("==================== INVERTED SEARCH DATABASE ====================\n");

    printf("+-------+------------+-------------+---------------+-------------+\n");
    printf("| Index | Word       | File Count | File Name     | Word Count |\n");
    printf("+-------+------------+-------------+---------------+-------------+\n");

    for(int i=0; i < HASH_SIZE ; i++)
    {
        if(arr[i].link == NULL)
        {
           continue;
        }
        flag=1; //data is present
        main_node *m_temp=arr[i].link;
        while(m_temp != NULL)
        {
            sub_node *s_temp=m_temp->sub_link;      //taking pointer to traverse through sub node
            int first=1;
            
            while(s_temp != NULL)          //to print  info
            {
                if(first)
                {
                    printf("| %-5d | %-10.10s | %-11d | %-13.13s | %-11d |\n", i, m_temp->word, m_temp->f_count, s_temp->file, s_temp->word_count);
                    first=0;
                }
                else
                {
                    printf("|       |            |             | %-13.13s | %-11d |\n",s_temp->file,s_temp->word_count);
                }
                s_temp = s_temp->sub_link;
            }
            printf("+-------+------------+-------------+---------------+-------------+\n");

            m_temp = m_temp->main_link; 
        }
    }
    printf("==================================================================\n");

    if(flag==0)
    return FAILURE;

    return SUCCESS;
}