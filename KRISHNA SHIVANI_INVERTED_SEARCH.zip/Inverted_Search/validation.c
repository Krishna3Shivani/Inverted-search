#include "inverted.h"
#include <string.h>

int validation(int argc, char *argv[])
{
    if(argc<2)
    {
        printf("No files passed!");
        return FAILURE;
    }
    for(int i=1;i<argc;i++)
    {
        if(strstr(argv[i],".txt") == NULL)              //check if it is a .txt file
        {
            printf("%s is not a .txt file\n",argv[i]);
            return FAILURE;
        }

        FILE *fptr = fopen(argv[i],"r");
        if(fptr == NULL)                               //checking if file is opened 
        {
            printf("%s is not found\n",argv[i]);
            return FAILURE;
        }
        if(fgetc(fptr) == EOF)                         //check if file is empty (checking if the 1st char reaches EOF)
        {
            printf("%s is empty\n",argv[i]);
            fclose(fptr);
            return FAILURE;
        }
        fclose(fptr);
    }
    for(int i=1;i<argc;i++)                         //check for duplicate files
    {
        for(int j=i+1;j<argc;j++)
        {
            if( strcmp(argv[i],argv[j]) == 0)
            {
                printf("Duplicate file %s is not allowed\n",argv[i]);
                return FAILURE;
            }
        }
    }
    return SUCCESS;
}