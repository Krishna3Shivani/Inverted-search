#include "inverted.h"

int update_db(hash_t arr[])
{
    char fname[50];
    printf("Enter backup file name:");
    scanf("%s",fname);  //read filename from user

    FILE *fptr=fopen(fname,"r");    //opening file in read mode
    if(fptr==NULL)
    {
        printf("Unable to open backup file\n");
        return FAILURE;
    }

    int index,f_count;
    char word[50];
    while(fscanf(fptr," #%d;%49[^;];%d;",&index,word,&f_count)==3)   //read from backup file
    {
        main_node *m_temp = arr[index].link;
        main_node *mprev = NULL; //previous node pointer
        while(m_temp != NULL)  //search word in main list
        {
            if(strcmp(m_temp->word,word)==0)
            break;
            mprev=m_temp;   //store previous node
            m_temp=m_temp->main_link;  //move forward
        }
        if(m_temp == NULL)  //if word not found,create main node
        {
            m_temp=malloc(sizeof(main_node));
            if(m_temp == NULL)
            {
                fclose(fptr);
                return FAILURE;
            }

            strcpy(m_temp->word, word);         // store word
            m_temp->f_count = 0;                // initialize file count
            m_temp->sub_link = NULL;            // no sub nodes yet
            m_temp->main_link = NULL;           // next main node NULL

            if(mprev == NULL)
            {
                arr[index].link = m_temp;
            }
            else
            {
                mprev->main_link = m_temp;
            }
        }
        else
        {
            // delete old sub-nodes (overwrite update)
            sub_node *del = m_temp->sub_link;
            while(del != NULL)
            {
               sub_node *next = del->sub_link;     // store next node
                free(del);                        // free current node
                del = next;                      // move forward
            }
            m_temp->sub_link = NULL;
        }
        m_temp->f_count=0;   // reset file count
        for(int i = 0; i < f_count; i++)   // insert new sub-nodes
        {
            char file_name[50];
            int word_count;
            if(fscanf(fptr, "%49[^;];%d;", file_name, &word_count) != 2)
            {
                fclose(fptr);
                return FAILURE;
            }
            sub_node *new = malloc(sizeof(sub_node));  // create sub node
            if(new == NULL)
            {
                fclose(fptr);
                return FAILURE;
            }
            strcpy(new->file, file_name);     // store file name
            new->word_count = word_count;          // store count
            new->sub_link = NULL;                 // next NULL
            if(m_temp->sub_link == NULL)           // first sub node
            {
                m_temp->sub_link = new;
            }
            else
            {
                sub_node *temp = m_temp->sub_link;   // traverse to last
                while(temp->sub_link != NULL)
                    temp = temp->sub_link;

                temp->sub_link = new;  //link new node
            }
            m_temp->f_count++;  // increment file count
        }
    }
    fclose(fptr);  // close file 
    return SUCCESS;
}